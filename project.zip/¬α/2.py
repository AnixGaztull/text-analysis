import csv
import json

# person_json = json.dumps(person_dict)
with open('stealth.csv') as csvfile:
    reader = csv.reader(csvfile, delimiter=';', quotechar='"')
    print(reader[0])
    for row in reader:
        if row[0] == "id":
            keys = row[2:]
            diction = {}
            for i in keys:
                diction[i] = []
        else:
            name = row[1]
            for i in range(2, len(row)):
                if row[i] == "1":
                    p = diction[keys[i - 2]]
                    p.append(name)
                    p.sort()
                    diction[keys[i - 2]] = p
    with open('hidden.json', 'w') as file:
        json.dump(diction, file)