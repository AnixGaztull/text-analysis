import requests
import json


def billywig(server, port, **kwargs):
    url = f"http://{server}:{port}"
    response = requests.get(url)
    s = response.json()
    k = s[kwargs["creature"]]
    keys_k = list(k.keys())
    for i in list(kwargs.keys()):
        if i != "creature":
            if i in keys_k:
                ere = s[kwargs["creature"]][i]
                ere.append(kwargs[i])
                s[kwargs["creature"]][i] = ere
            else:
                s[kwargs["creature"]][i] = kwargs[i]
    return json.dumps(k)
