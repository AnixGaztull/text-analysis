import sys
import csv
import json
from flask import Flask

app = Flask(__name__)

with open(sys.argv[6]) as csvfile:
    reader = csv.reader(csvfile, delimiter=';', quotechar='"')
    pot = []
    bundimun = []
    for row in reader:
        if row[0] == "id":
            keys = row[2:]
        else:
            if row[3] != 1 and row[4] != 1:
                p = {
                    "color": row[1],
                    "size": row[2],
                    "feet": row[4],
                    "habitat": row[5]
                }
                bundimun.append(p)
            else:
                k = {
                    "color": row[1],
                    "size": row[2],
                    "habitat": row[5]
                }
                pot.append(k)
    www = {"bundimun": bundimun,
           "pot": pot}
    file = json.dumps(www)


@app.route('/')
def page():
    return


@app.route('/pot/')
def landing_page():
    return file


if __name__ == '__main__':
    app.run(port=sys.argv[4], host=sys.argv[2])
