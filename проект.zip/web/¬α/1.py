import sys

data = list(map(str.strip, sys.stdin))
for i in data:
    max_lenght = 1
    k = 1
    for j in range(len(i) - 1):
        if i[j] == i[j + 1]:
            if k > max_lenght:
                max_lenght = k
            k = 1
        else:
            k += 1
    if k > max_lenght:
        max_lenght = k
    print(max_lenght)
