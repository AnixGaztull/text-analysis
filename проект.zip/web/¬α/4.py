import sqlite3

con = sqlite3.connect(input())
cur = con.cursor()
habit = input()
aggr = int(input())
result_1 = sorted(cur.execute(f"""SELECT color_id from demonds
WHERE aggression < {aggr}""").fetchall())
result_1.reverse()
for i in result_1:
    result_2 = cur.execute(f"""SELECT name from colors
        WHERE id == {i}""").fetchall()
    if len(result_2) > 1:
        for j in sorted(result_2):
            print(j, i)
    else:
        print(result_2[0], i)
con.close()
